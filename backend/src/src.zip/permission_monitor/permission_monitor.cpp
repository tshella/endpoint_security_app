#include "permission_monitor.h"
#include <iostream>

void PermissionMonitor::checkPermissions() {
    std::cout << "Checking permissions..." << std::endl;
}
